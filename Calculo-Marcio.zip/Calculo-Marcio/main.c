#include <stdio.h>

int permutation(int n) {
    if (n == 0) {
        return 1;
    }
    if (n == 1) {
        return 1;
    }
    int formula, acc;
    acc = 1;
    for (int i = 1; i < n; i++) {
        formula = n * (n - 1);
        acc *= formula;
    }

    return acc;
}

int main(void) {
    int option;
    printf("Menu Principal:\n");
    printf("(1) Sem Repeticao\n");
    printf("(2) Com Repeticao\n");
    printf("(3) Sair do Programa\n");
    scanf("%d", &option);
    switch (option) {
        case 1:
            int suboption;
            printf("Insira o numero para a permutacao:\n");
            scanf("%d", &suboption);
            printf("Permutation: %d", permutation(suboption));
            break;
    }
}
